praesentation_ai
================

SETUP (einmalig):
  1. Python 3.11 oder 3.12 installieren (mit "Add to PATH")
  2. ffmpeg installieren:  winget install ffmpeg
  3. In diesem Ordner PowerShell oeffnen:
     pip install openai-whisper spacy transformers torch librosa soundfile numpy scipy
     python -m spacy download de_core_news_sm

STARTEN:
  Video in daten\video\ ablegen, dann:
     python main.py daten\video\DEIN_VIDEO.mp4 --skip-video

ERGEBNIS:
  reports\gesamt\gesamt_report_*.txt
